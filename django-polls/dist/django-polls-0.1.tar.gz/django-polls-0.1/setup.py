#!/bin/env python3
# -*- coding utf-8 -*-
# @Author: Charramma(Huang)
# @E-mail: huang.zyn@qq.com
# @Time: 2021/1/4 19:51
# @File: setup.py
# @Software: Pycharm

from setuptools import setup

setup()